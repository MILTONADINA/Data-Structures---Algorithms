import java.util.Scanner;


public class PostfixTest {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in); // Create a scanner object to read input

        // Prompt the user to enter a postfix expression
        System.out.println("Enter a postfix expression:");
        String expression = scanner.nextLine(); // Read the entire line of input

        // Call the PostfixEvaluator to compute the result
        int result = PostfixEvaluator.evaluate(expression);

        // If evaluation is successful print the result
        if (result != Integer.MIN_VALUE) {
            System.out.println("Result: " + result);
        }

        scanner.close();
    }
}
