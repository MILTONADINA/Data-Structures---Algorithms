import java.util.Arrays;

public class DoublyLinkedListTest {
    public static void main(String[] args) {
        // Create a new doubly linked list
        DoublyLinkedList<String> myList = new DoublyLinkedList<>();

        // Add elements to the list
        myList.addFirst("USA");
        myList.addLast("Germany");
        myList.addFirst("France");
        myList.addLast("England");
        myList.addFirst("Belgium");

        // Print the list forward
        System.out.println("Forward List:");
        System.out.println(Arrays.toString(myList.toArrayFromFirst().toArray()));

        // Print the list in reverse order
        System.out.println("Reverse List:");
        System.out.println(Arrays.toString(myList.toArrayFromLast().toArray()));

        // Clone the list and print it
        DoublyLinkedList<String> clonedList = myList.clone();
        System.out.println("Cloned List:");
        System.out.println(Arrays.toString(clonedList.toArrayFromFirst().toArray()));

        // Remove elements and print the list again
        System.out.println("Removing first: " + myList.removeFirst());
        System.out.println("Removing last: " + myList.removeLast());
        System.out.println("Forward List after removals:");
        System.out.println(Arrays.toString(myList.toArrayFromFirst().toArray()));
    }
}
