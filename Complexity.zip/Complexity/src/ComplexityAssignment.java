public class ComplexityAssignment {

    //Algorithm 1
    public static void algorithm1(int n) {
        int sum = 0;
        for (int i = 0; i < n; i++) {
            sum += i;
        }
    }

    //Algorithm 2
    public static void algorithm2(int n) {
        int sum = 0;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                sum += i + j;
            }
        }
    }

    //Algorithm 3
    public static void algorithm3(int n) {
        int sum = 0;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n * n; j++) {
                sum += i + j;
            }
        }
    }

    //Algorithm 4
    public static void algorithm4(int n) {
        int sum = 0;
        if (n <= 0) return;
        for (int i = 1; i < n; i *= 2) {
            sum += i;
        }
    }

    //Algorithm 5
    public static void algorithm5(int n) {
        if (n <= 1) return;
        algorithm5(n - 1);
        algorithm5(n - 1);
    }

    // measure time
    public static long measureTime(Runnable algorithm) {
        long startTime = System.nanoTime();
        algorithm.run();
        long stopTime = System.nanoTime();
        return stopTime - startTime;
    }

    // Main 
    public static void main(String[] args) {

        //Algorithm 1
        System.out.println("Algorithm 1 Data"); 
        System.out.println("n,time(ns)");
        for (int nValue = 1000; nValue <= 15000; nValue += 1000) {
             final int currentN = nValue;
             long time = measureTime(() -> algorithm1(currentN));
             System.out.println(currentN + "," + time);
        }

        //Algorithm 2
        System.out.println("\nAlgorithm 2 Data"); 
        System.out.println("n,time(ns)");
        for (int nValue = 100; nValue <= 1500; nValue += 100) {
            final int currentN = nValue;
            long time = measureTime(() -> algorithm2(currentN));
            System.out.println(currentN + "," + time);
        }

        //Algorithm 3
        System.out.println("\nAlgorithm 3 Data");
        System.out.println("n,time(ns)");
        for (int nValue = 50; nValue <= 500; nValue += 50) {
            final int currentN = nValue;
            long time = measureTime(() -> algorithm3(currentN));
            System.out.println(currentN + "," + time);
        }

        //Algorithm 4
        System.out.println("\nAlgorithm 4 Data"); 
        System.out.println("n,time(ns)");
        for (long nValue = 1000; nValue <= 10000000; nValue *= 10) {
             final long currentN_long = nValue;
             final int currentN = (int) currentN_long;
             long time = measureTime(() -> algorithm4(currentN));
             System.out.println(currentN_long + "," + time);
        }

        //Algorithm 5
        System.out.println("\nAlgorithm 5 Data"); 
        System.out.println("n,time(ns)");
        for (int nValue = 1; nValue <= 25; nValue++) {
            final int currentN = nValue;
            long time = measureTime(() -> algorithm5(currentN));
            System.out.println(currentN + "," + time);
           
        }

        
    }
}