import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;


public class Test {

    public static void main(String[] args) {
        // Create Tree 
        BinaryTree<Integer, Student> studentTree = new BinaryTree<>();

        // csc Load
        String csvFilePath = "testdata.csv";

        try (BufferedReader br = new BufferedReader(new FileReader(csvFilePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                 line = line.trim();
                 if (line.isEmpty()) continue; // Skip empty lines 

                String[] parts = line.split(",", 2);
                if (parts.length == 2) {
                    try {
                        int id = Integer.parseInt(parts[0].trim());
                        String name = parts[1].trim();
                        Student student = new Student(id, name); 
                        studentTree.insert(student.getId(), student); //ID as key
                    } catch (NumberFormatException nfe) {
                        
                    }
                }
                 
            }
        } catch (IOException e) {
             
             System.err.println("Error reading file: " + csvFilePath);
             return; 
        }
        

        //Test

        System.out.println("Binary Tree Test"); 

        // Get Height
        int treeHeight = studentTree.height();
        System.out.println("Binary Tree Height = " + treeHeight); 

        //Search for key
        int searchId = 782209;
        System.out.println("\nSearch for " + searchId); 
        Student foundStudent = studentTree.search(searchId);
        if (foundStudent != null) {
             
            System.out.println("Search result: " + foundStudent); 
        } else {
            System.out.println("Search result: " + searchId + " not found"); 
        }

        //Remove key
        Student removedStudent = studentTree.remove(searchId);
        if (removedStudent != null) {
             //  
             System.out.println("\nRemoved " + removedStudent.getId()); 
        } else {
             // If removal failed
             System.out.println("\n" + searchId + " not found for removal.");
        }


        //Search key again 
        System.out.println("\nSearch for " + searchId); 
        foundStudent = studentTree.search(searchId); 
        if (foundStudent != null) {
             //unlikely
            System.out.println("Search result: " + foundStudent);
        } else {
             
            System.out.println("Search result: " + searchId + " not found"); 
        }

        
    }
}