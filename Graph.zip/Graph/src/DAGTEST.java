import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DAGTEST {

    public static void main(String[] args) {
        // TODO Auto-generated method stub

        String citiesFile    = "C:/Users/milto/eclipse-workspace/Graph/src/Cities (1).csv";
        String cityEdgesFile = "C:/Users/milto/eclipse-workspace/Graph/src/CityEdges.csv";
        Map<String, String> cityIndices = new HashMap<>();
        List<String> cities = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(citiesFile))) {
            String line;

            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                String city = parts[0];
                String name = parts[1];
                cityIndices.put(city, name);
                cities.add(city);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        DAG<String> graph = new DAG<>();

        for (String city : cities) {
            graph.addNode(city);
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(cityEdgesFile))) {
            String line;

            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                String source = parts[0];
                String destination = parts[1];
                int weight = Integer.parseInt(parts[2]);

                graph.addEdge(source, destination, weight);
                graph.addEdge(destination, source, weight);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        String startCity = "OKC";
        String endCity   = "HNL";

        List<String> shortestPath = graph.shortestPath(startCity, endCity);
        int totalWeight = graph.calculatePathWeight(shortestPath);

        // —— adjusted output to match the PDF exactly ——
        System.out.println("DAG Test");
        System.out.println("Shortest Path from " + startCity + " to " + startCity + " is " + totalWeight);
        for (String city : shortestPath) {
            System.out.println(city + " - " + cityIndices.get(city));
        }
    }

}
