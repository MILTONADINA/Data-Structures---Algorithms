
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class AVLTest {

    public static void main(String[] args) {
        // Create AVLTree instance 
        AVLTree<Integer, Student> studentTree = new AVLTree<>();
        String csvFile = "testdata.csv";
        String line = "";
        String csvSplitBy = ",";

        
System.out.println("Binary Tree Test"); 

        
        try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
            while ((line = br.readLine()) != null) {
                 line = line.trim();
                 if (line.isEmpty()) continue; 

                String[] studentData = line.split(csvSplitBy, 2); // Split into max 2 parts
                if (studentData.length == 2) {
                    try {
                        int id = Integer.parseInt(studentData[0].trim());
                        String name = studentData[1].trim();
                        Student student = new Student(id, name);
                        studentTree.insert(id, student); // Inset ID as key
                    } catch (NumberFormatException e) {
                        
                    }
                }
                 
            }
        } catch (IOException e) {
             
             System.err.println("Error reading file: " + csvFile);
             return; 
        }

        
        System.out.println("Binary Tree Height = " + studentTree.height());

        // Search for key
        int searchKey = 782209;
        System.out.println("\nSearch for " + searchKey);
        Student foundStudent = studentTree.search(searchKey);
        if (foundStudent != null) {
            System.out.println("Search result: " + foundStudent);
        } else {
            System.out.println("Search result: " + searchKey + " not found");
        }

        // Remove key 782209 
        Student removedStudent = studentTree.remove(searchKey);
         if (removedStudent != null) {
             System.out.println("\nRemoved " + removedStudent.getId()); // Matches sample output format
         } else {
              
              System.out.println("\nKey " + searchKey + " not found for removal.");
         }


        // Search again for key 
        System.out.println("\nSearch for " + searchKey);
        foundStudent = studentTree.search(searchKey); // Search again
        if (foundStudent != null) {
            
            System.out.println("Search result: " + foundStudent);
        } else {
            System.out.println("Search result: " + searchKey + " not found");
        }

        
    }
}