import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

public class DAGTest {

    public static void main(String[] args) {
        DirectedAcyclicGraph<City> cityGraph = new DirectedAcyclicGraph<>();

        // --- Reading Cities.csv data ---
        String citiesFilePath = "Cities.csv"; // Adjust path if needed
        try (BufferedReader br = new BufferedReader(new FileReader(citiesFilePath))) {
            String line;
            System.out.println("Reading cities from: " + citiesFilePath);
            while ((line = br.readLine()) != null) {
                String[] values = line.split(","); // Split by comma
                if (values.length >= 2) {
                    String code = values[0].trim();
                    String name = values[1].trim();
                    City city = new City(code, name);
                    cityGraph.addNode(code, city);
                     // System.out.println("Added City: " + city); // Optional: for debugging
                } else {
                    System.err.println("Warning: Skipping malformed line in Cities.csv: " + line);
                }
            }
             System.out.println("Finished reading cities.");
        } catch (FileNotFoundException e) {
            System.err.println("Error: Cities file not found at " + citiesFilePath);
            e.printStackTrace();
            return; // Exit if city file is essential and not found
        } catch (IOException e) {
            System.err.println("Error reading Cities file: " + citiesFilePath);
            e.printStackTrace();
            return; // Exit on read error
        }


        // --- Reading CityEdges.csv data ---
        String edgesFilePath = "CityEdges.csv"; // Adjust path if needed
        try (BufferedReader br = new BufferedReader(new FileReader(edgesFilePath))) {
            String line;
             System.out.println("\nReading edges from: " + edgesFilePath);
            while ((line = br.readLine()) != null) {
                String[] values = line.split(","); // Split by comma
                if (values.length >= 3) {
                    String cityCode1 = values[0].trim();
                    String cityCode2 = values[1].trim();
                    String distanceStr = values[2].trim();

                    City city1 = cityGraph.getNode(cityCode1);
                    City city2 = cityGraph.getNode(cityCode2);

                    if (city1 != null && city2 != null) {
                        try {
                            int distance = Integer.parseInt(distanceStr);
                            cityGraph.addEdge(city1, city2, distance);
                            cityGraph.addEdge(city2, city1, distance); // Add reverse edge as required
                             // System.out.println("Added Edge: " + cityCode1 + " <-> " + cityCode2 + " : " + distance); // Optional: for debugging
                        } catch (NumberFormatException e) {
                            System.err.println("Warning: Invalid distance format in CityEdges.csv: " + distanceStr + " on line: " + line);
                        }
                    } else {
                        System.err.println("Warning: Could not find one or both cities for edge in CityEdges.csv: " + cityCode1 + ", " + cityCode2 + " on line: " + line);
                    }
                } else {
                     System.err.println("Warning: Skipping malformed line in CityEdges.csv: " + line);
                }
            }
            System.out.println("Finished reading edges.");
        } catch (FileNotFoundException e) {
            System.err.println("Error: Edges file not found at " + edgesFilePath);
            e.printStackTrace();
            // Decide if you can continue without edges or should return
        } catch (IOException e) {
            System.err.println("Error reading Edges file: " + edgesFilePath);
            e.printStackTrace();
            // Decide if you can continue or should return
        }

        // --- Perform Shortest Path Calculation ---
        System.out.println("\nDAG Test");

        // Find shortest path (e.g., from OKC to HNL as in sample output path)
        City startCity = cityGraph.getNode("OKC");
        City endCity = cityGraph.getNode("HNL"); // Target based on sample output path

        if (startCity != null && endCity != null) {
            Map<String, Object> shortestPathResult = cityGraph.findShortestPath(startCity, endCity);
            Integer distance = (Integer) shortestPathResult.get("distance");
             List<City> path = (List<City>) shortestPathResult.get("path");


             // Print results matching sample output format
             // Note: The sample output "Shortest Path from OKC to OKC is 3960" seems unusual.
             // It likely meant the path *from* OKC *to* HNL has the total distance shown.
             // We print the calculated distance from startCity to endCity.
             if (distance != null && distance != -1 && path != null && !path.isEmpty()) {
                 System.out.println("\nShortest Path from " + startCity.getCode() + " to " + endCity.getCode() + " is " + distance);
                 for (City city : path) {
                    System.out.println(city.toString());
                 }
             } else {
                 System.out.println("\nNo path found from " + startCity.getCode() + " to " + endCity.getCode());
             }

        } else {
            System.err.println("\nError: Start or end city for path calculation not found in the graph. Check city codes.");
            if (startCity == null) System.err.println("Start city (OKC) is null or wasn't loaded.");
            if (endCity == null) System.err.println("End city (HNL) is null or wasn't loaded.");
        }
    }
}