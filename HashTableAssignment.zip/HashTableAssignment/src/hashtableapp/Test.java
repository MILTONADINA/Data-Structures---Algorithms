package hashtableapp;

import hashtable.HashTableDH;
import hashtable.HashTableLP;
import hashtable2.Student;

import java.io.File;
import java.io.FileNotFoundException; 
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Test {

    
    public static void main(String[] args) throws FileNotFoundException {
        String csvFilename = "hashdata.csv";
        int keyToTest = 782209;

        // Load Data
        List<Student> studentList = loadStudentsFromCSV(csvFilename);


        //Test LP
        System.out.println("\n--- Testing Linear Probing ---");
        testHashTable("LP", studentList, 100, keyToTest);
        testHashTable("LP", studentList, 200, keyToTest); 

        //Test DH
        System.out.println("\n--- Testing Double Hashing ---");
        testHashTable("DH", studentList, 100, keyToTest);
        testHashTable("DH", studentList, 200, keyToTest);
    }

    //CSV loader define
     
    public static List<Student> loadStudentsFromCSV(String filename) throws FileNotFoundException {
        List<Student> students = new ArrayList<>();
        // Use try-with-resources for Scanner auto-close (this doesn't catch the exception)
        try (Scanner scanner = new Scanner(new File(filename))) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] parts = line.split(",");
                int id = Integer.parseInt(parts[0]);
                String name = parts[1];
                students.add(new Student(id, name));
            }
        }
        return students;
    }

    //Tests func def
     
    public static void testHashTable(String type, List<Student> students, int tableSize, int keyToTest) {
        System.out.println("\nTest HashTable" + type + " with table size " + tableSize);

        if (type.equals("LP")) {
            HashTableLP<Student> tableLP = new HashTableLP<>(tableSize); // Create table
            for (Student student : students) {
                 tableLP.put(student.getId(), student); // Insert key
            }
            // collisions numb
            System.out.println("Number of Collisions = " + tableLP.getNumberOfTotalCollisions());

            // key is found
         Student foundStudent = tableLP.get(keyToTest);
            
            System.out.println("Name = " + (foundStudent != null ? foundStudent.getName() : "Not Found"));

            // Remove the object with key 
            tableLP.remove(keyToTest);

            // get for the same key 
            Student foundAfterRemove = tableLP.get(keyToTest);
            // Print out the results 
            System.out.println(keyToTest + (foundAfterRemove == null ? " not found" : " found (Error!)"));

        } else if (type.equals("DH")) {
            HashTableDH<Student> tableDH = new HashTableDH<>(tableSize); // Create table 
            for (Student student : students) {
                 tableDH.put(student.getId(), student); // Insert id
            }
            // Output number of collisions 
            System.out.println("Number of Put Collisions = " + tableDH.getNumberOfTotalPutCollisions());

            // Get object with key
            Student foundStudent = tableDH.get(keyToTest);
             // Print out the Student name
            System.out.println("Name = " + (foundStudent != null ? foundStudent.getName() : "Not Found"));

            // Remove the object with key
            tableDH.remove(keyToTest);

             // Do a get for the same key 
            Student foundAfterRemove = tableDH.get(keyToTest);
            // Print out the results 
            System.out.println(keyToTest + (foundAfterRemove == null ? " not found" : " found (Error!)"));
        }
    }
}